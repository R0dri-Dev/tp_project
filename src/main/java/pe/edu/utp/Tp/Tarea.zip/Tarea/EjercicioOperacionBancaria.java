package pe.edu.utp.Tp.Tarea;

import java.util.Scanner;

public class EjercicioOperacionBancaria {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("TICKET BANCARIO");

        String tipoOperacion, nombreCliente;
        long numeroCuenta;
        double monto, saldo;


        System.out.print("Ingrese nombre del cliente: ");
        nombreCliente = scanner.nextLine();

        System.out.print("Ingrese número de cuenta: ");
        numeroCuenta = scanner.nextLong();
        scanner.nextLine();

        System.out.print("Ingrese tipo de operación (Depósito/Retiro): ");
        tipoOperacion = scanner.nextLine();

        System.out.print("Ingrese monto: ");
        monto = scanner.nextDouble();

        System.out.print("Ingrese saldo actual: ");
        saldo = scanner.nextDouble();





        double nuevoSaldo;
        if (tipoOperacion.equalsIgnoreCase("Depósito")) {
            nuevoSaldo = saldo + monto;
        } else {
            nuevoSaldo = saldo - monto;
        }




        System.out.println("\n---------------------------------------");
        System.out.println("        TICKET BANCARIO");
        System.out.println("---------------------------------------");
        System.out.println("Cliente: " + nombreCliente.toUpperCase());
        System.out.println("Cuenta: " + numeroCuenta);
        System.out.println("Operación: " + tipoOperacion.toLowerCase());
        System.out.println("Monto: S/. " + monto);
        System.out.println("Saldo anterior: S/. " + saldo);
        System.out.println("Nuevo saldo: S/. " + nuevoSaldo);
        System.out.println("---------------------------------------");

        scanner.close();
    }

}
