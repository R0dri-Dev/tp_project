package pe.edu.utp.Tp.Tarea;

import java.util.Scanner;

public class EjerciciosTickets {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("BOLETO DE VIAJE INTERPROVINCIAL");




        String nombrePasajero, origen, destino;
        int numeroAsiento;
        double precio;




        System.out.print("Ingrese nombre del pasajero: ");
        nombrePasajero = scanner.nextLine();

        System.out.print("Ingrese ciudad de origen: ");
        origen = scanner.nextLine();

        System.out.print("Ingrese ciudad de destino: ");
        destino = scanner.nextLine();

        System.out.print("Ingrese número de asiento: ");
        numeroAsiento = scanner.nextInt();

        System.out.print("Ingrese precio del boleto: ");
        precio = scanner.nextDouble();
        scanner.nextLine();





        System.out.println("\n---------------------------------------");
        System.out.println("        BOLETO DE VIAJE");
        System.out.println("---------------------------------------");
        System.out.println("Pasajero: " + nombrePasajero.toUpperCase());
        System.out.println("Ruta: " + origen.toUpperCase() + " - " + destino.toLowerCase());
        System.out.println("Asiento: " + numeroAsiento);
        System.out.println("Precio: S/. " + precio);
        System.out.println("---------------------------------------");
    }
}
