package pe.edu.utp.Tp.Tarea;

import java.util.Scanner;

public class EjercicioBoletaPago {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("BOLETA DE PAGO");



        String nombreProducto;
        int cantidad;
        double precioUnitario;
        float porcentajeDescuento;




        System.out.print("Ingrese nombre del producto: ");
        nombreProducto = scanner.nextLine();

        System.out.print("Ingrese cantidad: ");
        cantidad = scanner.nextInt();

        System.out.print("Ingrese precio unitario: ");
        precioUnitario = scanner.nextDouble();

        System.out.print("Ingrese porcentaje de descuento: ");
        porcentajeDescuento = scanner.nextFloat();





        double subtotal = cantidad * precioUnitario;
        double descuento = subtotal * (porcentajeDescuento / 100);
        double total = subtotal - descuento;




        System.out.println("\n---------------------------------------");
        System.out.println("        BOLETA DE PAGO");
        System.out.println("---------------------------------------");
        System.out.println("Producto: " + nombreProducto.toUpperCase());
        System.out.println("Cantidad: " + cantidad);
        System.out.println("Precio unitario: S/. " + precioUnitario);
        System.out.println("Subtotal: S/. " + subtotal);
        System.out.println("Descuento (" + porcentajeDescuento + "%): S/. " + descuento);
        System.out.println("Total: S/. " + total);
        System.out.println("---------------------------------------");
    }
}
