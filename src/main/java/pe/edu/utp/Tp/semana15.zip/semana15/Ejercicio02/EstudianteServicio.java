package pe.edu.utp.Tp.semana15.Ejercicio02;

public class EstudianteServicio {

    public void mostrarEstudiante(Estudiante e) {
        System.out.println("Nombre: " + e.getNombre());
        System.out.println("Promedio: " + e.getPromedio());
    }

    public boolean aprobo(Estudiante e) {
        return e.getPromedio() >= 13.0;
    }
}

