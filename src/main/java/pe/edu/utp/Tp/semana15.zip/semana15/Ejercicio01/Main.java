package pe.edu.utp.Tp.semana15.Ejercicio01;

public class Main {
    public static void main(String[] args) {
        Producto producto = new Producto("Teclado", 75.0);
        ProductoServicio servicio = new ProductoServicio();

        servicio.mostrarProducto(producto);

        if (servicio.esPrecioValido(producto)) {
            System.out.println(" El precio es válido.");
        } else {
            System.out.println(" El precio es inválido.");
        }
    }
}
