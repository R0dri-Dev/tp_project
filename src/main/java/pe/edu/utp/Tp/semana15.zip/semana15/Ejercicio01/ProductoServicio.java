package pe.edu.utp.Tp.semana15.Ejercicio01;

public class ProductoServicio {

    public void mostrarProducto(Producto p) {
        System.out.println("Nombre: " + p.getNombre());
        System.out.println("Precio: " + p.getPrecio());
    }

    public boolean esPrecioValido(Producto p) {
        return p.getPrecio() > 0;
    }
}

